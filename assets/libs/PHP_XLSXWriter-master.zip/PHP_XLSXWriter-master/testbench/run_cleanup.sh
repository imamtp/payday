#!/bin/bash

rm -rf test/
rm -rf openoffice/
